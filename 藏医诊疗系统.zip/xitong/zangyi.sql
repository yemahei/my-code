-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 12 月 04 日 04:11
-- 服务器版本: 5.0.45
-- PHP 版本: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- 数据库: `zangyi`
--

-- --------------------------------------------------------

--
-- 表的结构 `ceshibiao`
--

CREATE TABLE `ceshibiao` (
  `id` tinyint(1) NOT NULL auto_increment,
  `username` varchar(20) character set gbk NOT NULL,
  `password` int(20) NOT NULL,
  `sex` varchar(5) character set gbk NOT NULL,
  `age` int(10) NOT NULL,
  `qq` int(20) NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(20) character set gbk NOT NULL,
  `address` varchar(50) character set gbk NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `ceshibiao`
--

INSERT INTO `ceshibiao` (`id`, `username`, `password`, `sex`, `age`, `qq`, `phone`, `email`, `address`) VALUES
(1, '张拂晓', 123, '男', 16, 1376806045, 2147483647, '1376806045@qq.com', '青海大学'),
(2, 'username', 0, '男', 15, 1376806045, 2147483647, '1376806045@qq.com', '青海大学'),
(3, '张拂晓·', 123456, '男', 18, 1376806045, 2147483647, '1376806045@qq.com', '青海大学');

-- --------------------------------------------------------

--
-- 表的结构 `docinf`
--

CREATE TABLE `docinf` (
  `id` tinyint(4) NOT NULL auto_increment,
  `username` varchar(20) character set gbk NOT NULL,
  `sex` varchar(20) character set gbk NOT NULL,
  `age` int(20) NOT NULL,
  `keshi` varchar(20) character set gbk NOT NULL,
  `jianli` varchar(500) character set gbk NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(20) character set gbk NOT NULL,
  `address` varchar(100) character set gbk NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- 导出表中的数据 `docinf`
--

INSERT INTO `docinf` (`id`, `username`, `sex`, `age`, `keshi`, `jianli`, `phone`, `email`, `address`) VALUES
(1, '张拂晓', '男', 23, '泌尿科', '我是青海大学医学院的一个泌尿科医生', 2147483647, '1376806045@qq.com', '        青海大学'),
(2, '张毅', '男', 18, '妇产科', '青海大学医学院有名的妇产科医生', 2147483647, '1376806045@qq.com', '        青海大学17号公寓220室'),
(3, '王志忠', '男', 25, '胸外科', '胸外科有名的医生', 2147483647, '1376806045@qq.com', '        青海民族大学18栋楼220室'),
(4, '张拂晓', '男', 25, '胸外科', '', 2147483647, '1376806045@qq.com', ''),
(5, '张拂晓', '男', 25, '胸外科', '', 2147483647, '1376806045@qq.com', '');

-- --------------------------------------------------------

--
-- 表的结构 `guahao`
--

CREATE TABLE `guahao` (
  `id` tinyint(4) NOT NULL auto_increment,
  `keshi` varchar(20) character set gbk NOT NULL,
  `username` varchar(20) character set gbk NOT NULL,
  `room` int(20) NOT NULL,
  `time` text character set gbk NOT NULL,
  `sex` varchar(20) character set gbk NOT NULL,
  `age` int(20) NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(20) character set gbk NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 导出表中的数据 `guahao`
--

INSERT INTO `guahao` (`id`, `keshi`, `username`, `room`, `time`, `sex`, `age`, `phone`, `email`) VALUES
(1, '胸外科', '李四', 202, '2017年10月18号上午九点', '男', 25, 2147483647, '1376806045@qq.com'),
(2, '内科', '张拂晓', 203, '2017年10月18日九点半', '男', 25, 2147483647, '1376806045@qq.com');

-- --------------------------------------------------------

--
-- 表的结构 `huanzhe`
--

CREATE TABLE `huanzhe` (
  `id` tinyint(4) NOT NULL auto_increment,
  `username` varchar(20) character set gbk NOT NULL,
  `sex` varchar(20) character set gbk NOT NULL,
  `age` int(20) NOT NULL,
  `bingqing` varchar(200) character set gbk NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(20) character set gbk NOT NULL,
  `address` varchar(200) character set gbk NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `huanzhe`
--

INSERT INTO `huanzhe` (`id`, `username`, `sex`, `age`, `bingqing`, `phone`, `email`, `address`) VALUES
(2, '张三', '男', 25, '头痛、恶心、嗓子痛、鼻塞', 2147483647, '1376806045@qq.com', '      青海师范大学  '),
(3, '李四', '男', 26, '上腹部隐痛、胀满、嗳气，食欲不振，或消瘦、贫血', 2147483647, '1376806045@qq.com', '        青海民族大学');

-- --------------------------------------------------------

--
-- 表的结构 `keshi`
--

CREATE TABLE `keshi` (
  `id` tinyint(5) NOT NULL auto_increment,
  `name` varchar(20) character set gbk NOT NULL,
  `lx` varchar(20) character set gbk NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 导出表中的数据 `keshi`
--

INSERT INTO `keshi` (`id`, `name`, `lx`) VALUES
(1, '202', '胸外科'),
(2, '203', '肿瘤科');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userflag` int(11) NOT NULL,
  `style` varchar(10) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `age` int(10) NOT NULL,
  `qq` int(20) NOT NULL,
  `phone` int(20) NOT NULL,
  `email` varchar(50) default 'default null',
  `address` varchar(100) default 'default null',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=gbk AUTO_INCREMENT=10 ;

--
-- 导出表中的数据 `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `userflag`, `style`, `sex`, `age`, `qq`, `phone`, `email`, `address`) VALUES
(1, '张拂晓', '123456', 0, '医生', '男', 15, 0, 2147483647, '1376806045@qq.com', '        青海大学'),
(2, '罗佩聪', '123456789', 0, '患者', '女', 25, 0, 123456789, '1376806045@qq.com', '        青海大学'),
(3, '', '', 0, '', '', 0, 0, 0, '', '        '),
(4, '张拂晓', '', 0, '', '男', 45, 0, 2147483647, '1376806045@qq.com', '       青海大学宿舍楼17栋220室 '),
(5, '张拂晓', '', 0, '', '男', 45, 0, 2147483647, '1376806045@qq.com', '       青海大学宿舍楼17栋220室 '),
(6, '张三', '', 0, '', '男', 25, 0, 2147483647, '1376806045@qq.com', '        青海师范大学'),
(7, '张三', '', 0, '', '男', 25, 0, 2147483647, '1376806045@qq.com', '        青海师范大学'),
(8, '张三', '', 0, '', '男', 25, 0, 2147483647, '1376806045@qq.com', '        青海师范大学'),
(9, '张三', '', 0, '', '男', 25, 0, 2147483647, '1376806045@qq.com', '        青海师范大学');

-- --------------------------------------------------------

--
-- 表的结构 `yaopin`
--

CREATE TABLE `yaopin` (
  `id` tinyint(4) NOT NULL auto_increment,
  `name` varchar(20) character set gbk NOT NULL,
  `bz` varchar(20) character set gbk NOT NULL,
  `guige` varchar(20) character set gbk NOT NULL,
  `cc` varchar(20) character set gbk NOT NULL,
  `kc` varchar(20) character set gbk NOT NULL,
  `lx` varchar(50) character set gbk NOT NULL,
  `yf` varchar(100) character set gbk NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `yaopin`
--

INSERT INTO `yaopin` (`id`, `name`, `bz`, `guige`, `cc`, `kc`, `lx`, `yf`) VALUES
(1, '人工牛黄甲硝唑胶囊', '塑料包装，10粒x2板/盒', '甲硝唑0.2g，人工牛黄5mg', '黑龙江明水三精医药工业园区', '50', '用于急性智齿冠周炎、局部牙槽囊肿、牙髓炎', '        口服、一次两粒、一日两次');
