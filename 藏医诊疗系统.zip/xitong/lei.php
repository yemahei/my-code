<?php
class QiChe
{
  public $localhost="localhost";//服务器
  public $uid="root";//用户名
  public $password="";//密码
  //执行查询语句sql方法：
  //参数的含义：$sql代表要执行的sql语句；$type代表sql语句的类型，自义0为查询，1为其他（增删改查）；$db代表要查询的数据库
  public function Query($sql,$type="0",$db="mydb")
  {
    $dbconnect=new MySQLi($this->localhost,$this->uid,$this->password,$db);
    !mysqli_connect_error() or die("连接失败 ！");
    $result=$dbconnect->query($sql);
      
    if($type==0)
    {
      return $result->fetch_all();
    }
    else
    {
      return $result;
    }
  } 
}