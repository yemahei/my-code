<?php  
//header('Content-Type:text/html;charset=utf-8');
$conn = @mysql_connect("localhost","root","") or die ("链接错误");
mysql_select_db("zangyi",$conn);
mysql_query("set names UTF8");
$username = $_POST['username'];  
$password = $_POST['password']; 
//检测用户名及密码是否正确  
$check_query = @mysql_query("select username, userflag from users"."where username='$username' and password='$password'");
  //or die("SQL语句执行失败") ;  
if($row = mysql_fetch_array($check_query)){  
    //登录成功  
    session_start();  
if($row['userflag'] == 1 or $row['userflag'] == 0) 
{
  $_SESSION['username'] = $row['username'];
  $_SESSION['userflag'] = $row['userflag'];
  echo "<a href='index1.php'>欢迎登陆。</a>";

  }

  else {  
      echo "用户权限信息不正确";  
      } 
}
else
{
    echo "用户名或密码错误";
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>藏医诊疗系统</title>
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<!-- -->
<script>var __links = document.querySelectorAll('a');function __linkClick(e) { parent.window.postMessage(this.href, '*');} ;for (var i = 0, l = __links.length; i < l; i++) {if ( __links[i].getAttribute('data-t') == '_blank' ) { __links[i].addEventListener('click', __linkClick, false);}}</script>
<script src="js1/jquery.min.js"></script>
<script>$(document).ready(function(c) {
  $('.alert-close').on('click', function(c){
    $('.message').fadeOut('slow', function(c){
        $('.message').remove();
    });
  });   
});
</script>
</head>
<body>
<!-- contact-form --> 
<div class="message warning">
<div class="inset">
  <div class="login-head">
    <h1>藏医诊疗管理系统</h1>
     <div class="alert-close"> </div>       
  </div>
    <form name='formal' method='post' action='index.php'>
      <li>
        <input type="text" class="text" value="username" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Username';}"><a href="#" class=" icon user"></a>
      </li>
        <div class="clear"> </div>
      <li>
        <input type="password" value="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}"> <a href="#" class="icon lock"></a>
      </li>
      <div class="clear"> </div>
      <div class="submit">
        <input type="submit" onclick="myFunction()" value="登录" name="submit" ><a href="xitong\index1.php">
        <h4><a href="zhecedenglu1.php">注册</a></h4><h4><a href="#">忘记密码 ?</a></h4>
        
              <div class="clear">  </div> 
      </div>
     
    </form>
    </div>          
  </div>
  </div>
  <div class="clear"> </div>
<!--- footer --->
<div class="footer">
  <p>青大计算机系</p>
</div>
<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>
</body>
</html>