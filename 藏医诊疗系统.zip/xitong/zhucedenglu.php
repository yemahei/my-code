<?php
$conn=mysql_connect('localhost','root','')or die('数据库连接错误');
mysql_select_db('zangyi',$conn);
mysql_query("set names 'gbk'");
//检测会员名称是否存在
if($_post['sub']){
  $sql="select * from users where username='$_post[username]'";
  $res=mysql_query($sql)or die("查询失败！");
  $us=$_post[username];
  echo $us."222222";
  $ps= md5($_post[password]);
  $style=$_post['style'];
  $sex=$_post['sex'];
  $age=$_post['age'];
  $qq=$_post['qq'];
  $phone=$_post['phone'];
  $email=$_post['email'];
  $address=$_post['address'];
  if(is_array(mysql_fetch_row($res))){
       echo "该会员名已经存在！";
  }else{
        $sql="insert into users (id,username,password,style,sex,age,qq,phone,email,address)".
      "value('','$_POST[username]','$_POST[password]','$_POST[style]','$_POST[sex]','$_POST[age]','$_POST[qq]','$_POST[phone]','$_POST[email]','$_POST[address]')";
        echo $sql;
       mysql_query($sql)or die("注册失败");
       echo "<script>alert('注册成功');location.href='login.php'</script>";
  }
}
?>
<script language="网页特效" type="text/javascript">
function docheck(){
var username = document.regform.username.value;
var pwd =document.regform.password.value;
var repwd=document.regform.repassword.value;
if(username==""){
  alert("请输入用户名！");
    return false;
}
if(pwd==""){
  alert("请输入密码！");
    return false;
}
if(repwd != pwd){
  alert("两次填写的密码不相同！");
  return false;
}
}
</script>
<script language="javascript">
function createxmlhttprequest(){
 var xmlhttp;
 if(window.activexobject){
  xmlhttp = new activexobject("microsoft.xmlhttp");
 }else{
  xmlhttp = new xmlhttprequest();
 }
 //return xmlhttp;
}
function checkname(){
 var name = document.getelementbyid('username'); //获取用户名文本框
 var span = document.getelementbyid('name_info'); //获取用于显示结果的span标记
 if(name.value.length <= 4){
  span.style.color = '#ff0000'; //设置span标记内的字体颜色为红色
  span.innerhtml = '用户名长度不能少于4个字符！'; //span标记内容
  return false;
 }
 var xmlhttp = createxmlhttprequest();//创建异步请求对象
 var time = new date().gettime();
 var url = 'index.php?name=' + name.value + '&tmp=' + time;//构造出请求地址
 xmlhttp.open("get",url,true); //建立一个异步请求
 //这里我们使用get方式请求
 xmlhttp.onreadystatechange = function(){ //监视请求状态
  span.style.color = '#ff9900';
  span.innerhtml = '查询中，请稍候！';
  if(xmlhttp.readystate == 4 && xmlhttp.status == 200){
alert(xmlhttp.responsetext+"........");
   if(xmlhttp.responsetext.indexof('no') != -1){ //如果服务器返回的信息中有no
    span.style.color = '#cb2121'; //设置span标记颜色为红色
    span.innerhtml = '用户名[' + name.value + ']已经被别的用户使用！';
    //document.regform.username.value="";
   }else{//如果返回信息中没有no
    span.style.color = '#00a800';//设置颜色为绿色
    span.innerhtml = '恭喜您，该用户名未被注册!';
   }
   return true;
   delete xmlhttp; //删除请求对象
  }
 }
 xmlhttp.send(null); //发送请求
}
</script>
  <form action="index.php" method="post" onsubmit="return docheck()" name="regform">
  姓名：
  <input type="text" name="username" value="" id="username" onblur="checkname()"/>
<span id="name_info"></span>
  <br>
  密&nbsp;&nbsp;&nbsp;&nbsp;码：
  <input type="password" name="password" value=""/><br>
  确认密码：
  <input type="password" name="repassword" value=""/><br>
性别：
男：<input name="sex" type="radio" value="0" checked="checked"/>
女：<input name="sex" type="radio" value="1"/><br>
类型：
医生：<input name="style" type="radio" value="0" checked="checked"/>
患者：<input name="style" type="radio" value="1"/><br>
年龄：<input type="text" name="age" value=""/><br>
qq：<input type="text" name="qq" value=""/><br>
电话：<input type="text" name="phone" value=""/><br>
email：<input type="text" name="email" value=""/><br>
地址：<input type="text" name="address" value=""/><br>
  <input type="submit" name="sub" value="注册"/>
  <input type="reset" name="re" value="取消"/>
  </form>